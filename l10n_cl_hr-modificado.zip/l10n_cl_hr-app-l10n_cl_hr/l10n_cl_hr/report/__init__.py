from . import report_payslip
from . import amount_to_text_es
from . import report_hr_salary_book
